package bolsaEmpleo;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "aspirantes")

public class aspirante {
    @DatabaseField(id = true)
    private String cedula;
    @DatabaseField
    private String nombre;
    @DatabaseField
    private int edad;
    @DatabaseField
    private int experienciaEnAnos;
    @DatabaseField
    private String profesion;
    @DatabaseField
    private String telefono;

    public aspirante() {}

    public aspirante(String cedula, String nombre, int edad, int experienciaEnAnos, String profesion, String telefono) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.edad = edad;
        this.experienciaEnAnos = experienciaEnAnos;
        this.profesion = profesion;
        this.telefono = telefono;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getExperienciaEnAnos() {
        return experienciaEnAnos;
    }

    public String getProfesion() {
        return profesion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setExperienciaEnAnos(int experienciaEnAnos) {
        this.experienciaEnAnos = experienciaEnAnos;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
