package bolsaEmpleo;

import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.Connection;
import java.sql.SQLDataException;
import java.sql.SQLException;

public class CrearTablasBolsa {
    public static void main(String[] args) throws Exception {
        String url = "jdbc:h2:file:./bolsaEmpleo";
        ConnectionSource con =
               new  JdbcConnectionSource(url);
        TableUtils.createTable(con, aspirante.class);
        con.close();
    }
}
