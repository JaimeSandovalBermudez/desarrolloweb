
package bolsaEmpleo;

import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.logger.Level;
import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.support.ConnectionSource;
import org.h2.engine.Database;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;



public class ManejadorBolsa {

    public static void main(String[] args) throws Exception {
        Logger.setGlobalLogLevel(Level.OFF);
        Scanner teclado = new Scanner(System.in);
        String url = "jdbc:h2:file:./bolsaEmpleo";
        ConnectionSource con = new JdbcConnectionSource(url);
        Dao<aspirante, String> listaAspirantes = DaoManager.createDao(con, aspirante.class);

        System.out.println("Bienvenido a la Bolsa de empleo, selecciona la opción que deseas realizar:");

        int opcion = 0;
        do {
            System.out.println("1. Agregar nuevo aspirante");
            System.out.println("2. Mostrar todas las cédulas de los aspirantes");
            System.out.println("3. Mostrar información detallada de un aspirante por cédula");
            System.out.println("4. Buscar aspirante por nombre");
            System.out.println("5. Ordenar la lista de aspirantes por los diferentes criterios: años de experiencia, edad y profesión.");
            System.out.println("6. Consultar el aspirante con mayor experiencia");
            System.out.println("7. Consultar el aspirante más joven");
            System.out.println("8. Contratar un aspirante");
            System.out.println("9. Eliminar aspirante cuya experiencia sea menor a una cantidad de años especificada");
            System.out.println("10. Consultar el promedio de edad de los aspirantes");
            System.out.println("0. Salir");
            System.out.println("> ");
            opcion = teclado.nextInt();


            switch (opcion) {

                case 1:
                    teclado.nextLine();
                    System.out.println("> Ingresa el número de cédula del aspirante: ");
                    String cedula = teclado.nextLine();
                    System.out.println("> Ingresa el nombre del aspirante: ");
                    String nombre = teclado.nextLine();
                    System.out.println("> Ingresa la edad del aspirante: ");
                    int edad = teclado.nextInt();
                    System.out.println("> Ingresa la experiencia en años del aspirante: ");
                    int experienciaEnAnos = teclado.nextInt();
                    teclado.nextLine();
                    System.out.println("> Ingresa la profesión del aspirante: ");
                    String profesion = teclado.nextLine();
                    System.out.println("> Ingresa el teléfono del aspirante: ");
                    String telefono = teclado.nextLine();

                    aspirante aspirante = new aspirante(cedula, nombre, edad, experienciaEnAnos, profesion, telefono);
                    listaAspirantes.create(aspirante);
                    System.out.println("¡ASPIRANTE AGREGADO EXITOSAMENTE!");
                    break;
                case 2:
                    List<aspirante> aspirantes = listaAspirantes.queryForAll();
                    System.out.println("Las siguientes son las cédulas de todos los aspirantes:");
                    for (aspirante a : aspirantes) {
                        System.out.println("> " + a.getCedula());
                    }
                    break;
                case 3:
                    teclado.nextLine();
                    System.out.println("> Ingresa la cédula del aspirante: ");
                    String cedulaBuscada = teclado.nextLine();
                    aspirante aspiranteBuscado = listaAspirantes.queryForId(cedulaBuscada);
                    if (aspiranteBuscado != null) {
                        System.out.println("Información detallada del aspirante con cédula " + cedulaBuscada + ":");
                        System.out.println("- Nombre: " + aspiranteBuscado.getNombre());
                        System.out.println("- Edad: " + aspiranteBuscado.getEdad());
                        System.out.println("- Experiencia en años: " + aspiranteBuscado.getExperienciaEnAnos());
                        System.out.println("- Profesión: " + aspiranteBuscado.getProfesion());
                        System.out.println("- Teléfono: " + aspiranteBuscado.getTelefono());
                    } else {
                        System.out.println("No se encontró un aspirante con la cédula ingresada");
                    }
                    break;

                case 4:
                    teclado.nextLine();
                    System.out.println("> Ingresa el nombre del aspirante: ");
                    String nombreBusqueda = teclado.nextLine();
                    List<aspirante> aspirantesBusqueda = listaAspirantes.queryForEq("nombre", nombreBusqueda);
                    if (aspirantesBusqueda.isEmpty()) {
                        System.out.println("No se encontraron aspirantes con ese nombre.");
                    } else {
                        for (aspirante a : aspirantesBusqueda) {
                            System.out.println("Cédula: " + a.getCedula());
                            System.out.println("Nombre: " + a.getNombre());
                            System.out.println("Edad: " + a.getEdad());
                            System.out.println("Experiencia en años: " + a.getExperienciaEnAnos());
                            System.out.println("Profesión: " + a.getProfesion());
                            System.out.println("Teléfono: " + a.getTelefono());
                            System.out.println("-----------------------------");
                        }
                    }
                    break;

                case 5:
                    System.out.println("Elige un criterio de ordenamiento:");
                    System.out.println("1. Años de experiencia");
                    System.out.println("2. Edad");
                    System.out.println("3. Profesión");
                    int opcionOrdenamiento = teclado.nextInt();
                    List<aspirante> aspirantesOrdenados = null;
                    switch (opcionOrdenamiento) {
                        case 1:
                            aspirantesOrdenados = listaAspirantes.queryBuilder().orderBy("experienciaEnAnos", false).query();
                            break;
                        case 2:
                            aspirantesOrdenados = listaAspirantes.queryBuilder().orderBy("edad", true).query();
                            break;
                        case 3:
                            aspirantesOrdenados = listaAspirantes.queryBuilder().orderBy("profesion", true).query();
                            break;
                        default:
                            System.out.println("Opción no válida.");
                            break;

                    }
                    if (aspirantesOrdenados != null) {
                        for (aspirante a : aspirantesOrdenados) {
                            System.out.println("Cédula: " + a.getCedula());
                            System.out.println("Nombre: " + a.getNombre());
                            System.out.println("Edad: " + a.getEdad());
                            System.out.println("Experiencia en años: " + a.getExperienciaEnAnos());
                            System.out.println("Profesión: " + a.getProfesion());
                            System.out.println("Teléfono: " + a.getTelefono());
                            System.out.println("-----------------------------");
                        }
                    }
                    break;

                case 6:
                    aspirante mayorExperiencia = listaAspirantes.queryBuilder().orderBy("experienciaEnAnos", false).queryForFirst();
                    if (mayorExperiencia != null) {
                        System.out.println("El aspirante con mayor experiencia es:");
                        System.out.println("Cédula: " + mayorExperiencia.getCedula());
                        System.out.println("Nombre: " + mayorExperiencia.getNombre());
                        System.out.println("Edad: " + mayorExperiencia.getEdad());
                        System.out.println("Experiencia en años: " + mayorExperiencia.getExperienciaEnAnos());
                        System.out.println("Profesión: " + mayorExperiencia.getProfesion());
                        System.out.println("Teléfono: " + mayorExperiencia.getTelefono());
                    } else {
                        System.out.println("No se encontraron aspirantes registrados.");
                    }
                    break;

                case 7:
                    aspirante masJoven = listaAspirantes.queryBuilder().orderBy("edad", true).queryForFirst();
                    if (masJoven != null) {
                        System.out.println("El aspirante más joven es:");
                        System.out.println("Cédula: " + masJoven.getCedula());
                        System.out.println("Nombre: " + masJoven.getNombre());
                        System.out.println("Edad: " + masJoven.getEdad());
                        System.out.println("Experiencia en años: " + masJoven.getExperienciaEnAnos());
                        System.out.println("Profesión: " + masJoven.getProfesion());
                        System.out.println("Teléfono: " + masJoven.getTelefono());
                    } else {
                        System.out.println("No se encontraron aspirantes registrados.");
                    }
                    break;

                case 8:
                    System.out.println("> Ingresa la cédula del aspirante que deseas contratar: ");
                    teclado.nextLine();
                    String cedulaContratar = teclado.nextLine();
                    aspirante aspiranteContratar = listaAspirantes.queryForId(cedulaContratar);
                    if (aspiranteContratar != null) {
                        listaAspirantes.delete(aspiranteContratar);
                        System.out.println("El aspirante con cédula " + cedulaContratar + " ha sido contratado.");
                    } else {
                        System.out.println("No se encontró ningún aspirante con la cédula " + cedulaContratar + ".");
                    }
                    break;

                case 9:
                    System.out.println("> Ingresa la cantidad de años de experiencia mínima que deben tener los aspirantes a conservar: ");
                    int experienciaMinima = teclado.nextInt();
                    List<aspirante> aspirantesExperiencia = listaAspirantes.queryBuilder()
                            .where().ge("experienciaEnAnos", experienciaMinima)
                            .query();
                    int cantidadEliminados = 0;
                    for (aspirante aspiranteEliminar : listaAspirantes) {
                        if (aspiranteEliminar.getExperienciaEnAnos() < experienciaMinima) {
                            listaAspirantes.delete(aspiranteEliminar);
                            cantidadEliminados++;
                        }
                    }
                    System.out.println(cantidadEliminados + " aspirantes con experiencia menor a " + experienciaMinima + " años han sido eliminados.");
                    break;
                case 10:
                    List<aspirante> listaCompleta = listaAspirantes.queryForAll();
                    int sumaEdades = 0;
                    for (aspirante aspirantess : listaCompleta) {
                        sumaEdades += aspirantess.getEdad();
                    }
                    double promedioEdad = (double) sumaEdades / listaCompleta.size();
                    System.out.println("El promedio de edad de los aspirantes es: " + promedioEdad);
                    break;

                case 0:
                    System.out.println("Saliendo del programa...");
                    opcion = -1;
                    break;


                default:
                    throw new IllegalStateException("Unexpected value: " + opcion);
            }
            con.close();

        }while (opcion != 0);
    }
    
}